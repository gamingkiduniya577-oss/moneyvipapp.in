const https = require('https');
const urls = [
  "https://netavipapp.com/01-slots/",
  "https://netavipapp.com/rumble-rummy/",
  "https://netavipapp.com/yes-spin-yono/",
  "https://netavipapp.com/789-jackpots/",
  "https://netavipapp.com/join-yono-games/",
  "https://netavipapp.com/yono-vip-fast/",
  "https://netavipapp.com/saga-slots/"
];

async function fetchMeta(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        const titleMatch = data.match(/<title>([^<]*)<\/title>/i);
        const ogImageMatch = data.match(/<meta property="og:image" content="([^"]*)"/i);
        resolve({
          url,
          title: titleMatch ? titleMatch[1] : 'Unknown Title',
          image: ogImageMatch ? ogImageMatch[1] : 'Unknown Image'
        });
      });
    }).on('error', reject);
  });
}

async function run() {
  for (const url of urls) {
    const res = await fetchMeta(url);
    console.log(`URL: ${res.url}`);
    console.log(`Title: ${res.title}`);
    console.log(`Image: ${res.image}`);
    console.log('---');
  }
}
run();
