const https = require('https');
const urls = [
  "https://netavipapp.com/567-slots-yono/",
  "https://netavipapp.com/bet-213-slots/",
  "https://netavipapp.com/good-slots/",
  "https://netavipapp.com/bingo-101-yono/",
  "https://netavipapp.com/ind-club-app/",
  "https://netavipapp.com/hindi-777-game/",
  "https://netavipapp.com/paglu-game/",
  "https://netavipapp.com/777-game-download/",
  "https://netavipapp.com/remi-101-all/",
  "https://netavipapp.com/bet-11/"
];

async function fetchMeta(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        const titleMatch = data.match(/<title>([^<]*)<\/title>/i);
        const ogImageMatch = data.match(/<meta property="og:image" content="([^"]*)"/i);
        resolve({
          url,
          title: titleMatch ? titleMatch[1] : 'Unknown Title',
          image: ogImageMatch ? ogImageMatch[1] : 'Unknown Image'
        });
      });
    }).on('error', reject);
  });
}

async function run() {
  for (const url of urls) {
    const res = await fetchMeta(url);
    console.log(`URL: ${res.url}`);
    console.log(`Title: ${res.title}`);
    console.log(`Image: ${res.image}`);
    console.log('---');
  }
}
run();
