const https = require('https');
const urls = [
  "https://netavipapp.com/rummy-ares/",
  "https://netavipapp.com/slots-spin/",
  "https://netavipapp.com/teen-patti-gold/",
  "https://netavipapp.com/teen-patti-dhan/",
  "https://netavipapp.com/spin-gold/",
  "https://netavipapp.com/spin-winner/",
  "https://netavipapp.com/spin-101/",
  "https://netavipapp.com/spin-777-yono/",
  "https://netavipapp.com/game-rummy/",
  "https://netavipapp.com/le-777-yono/"
];

async function fetchMeta(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        const titleMatch = data.match(/<title>([^<]*)<\/title>/i);
        const ogImageMatch = data.match(/<meta property="og:image"\s*content="([^"]*)"/i) || data.match(/<meta property="og:image"\s*content='([^']*)'/i);
        resolve({
          url,
          title: titleMatch ? titleMatch[1] : 'Unknown Title',
          image: ogImageMatch ? ogImageMatch[1] : 'Unknown Image'
        });
      });
    }).on('error', reject);
  });
}

async function run() {
  for (const url of urls) {
    const res = await fetchMeta(url);
    console.log(`URL: ${res.url}`);
    console.log(`Title: ${res.title}`);
    console.log(`Image: ${res.image}`);
    console.log('---');
  }
}
run();
