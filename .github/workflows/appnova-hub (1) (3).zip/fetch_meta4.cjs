const https = require('https');
const urls = [
  "https://netavipapp.com/dvip-apk-download/",
  "https://netavipapp.com/mt-game-apk/",
  "https://netavipapp.com/ind-bet-apps-download/",
  "https://netavipapp.com/888i-com-app/",
  "https://netavipapp.com/777-game-download-2/",
  "https://netavipapp.com/diwa-777-game/",
  "https://netavipapp.com/bet-51/",
  "https://netavipapp.com/teen-patti-dream-11/",
  "https://netavipapp.com/ace379-game/",
  "https://netavipapp.com/game-3f-apk/"
];

async function fetchMeta(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        const titleMatch = data.match(/<title>([^<]*)<\/title>/i);
        const ogImageMatch = data.match(/<meta property="og:image"\s*content="([^"]*)"/i) || data.match(/<meta property="og:image"\s*content='([^']*)'/i);
        resolve({
          url,
          title: titleMatch ? titleMatch[1] : 'Unknown Title',
          image: ogImageMatch ? ogImageMatch[1] : 'Unknown Image'
        });
      });
    }).on('error', reject);
  });
}

async function run() {
  for (const url of urls) {
    const res = await fetchMeta(url);
    console.log(`URL: ${res.url}`);
    console.log(`Title: ${res.title}`);
    console.log(`Image: ${res.image}`);
    console.log('---');
  }
}
run();
