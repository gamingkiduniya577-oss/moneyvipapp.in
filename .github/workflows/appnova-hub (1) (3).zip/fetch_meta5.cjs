const https = require('https');
const urls = [
  "https://netavipapp.com/diwa-777-apk/",
  "https://netavipapp.com/mqm-bet-yono/",
  "https://netavipapp.com/top-one/",
  "https://netavipapp.com/8-game/",
  "https://netavipapp.com/shubhkhel-game-apk/",
  "https://netavipapp.com/a66-game-app/",
  "https://netavipapp.com/hu-777/",
  "https://netavipapp.com/okmm-game-apk/",
  "https://netavipapp.com/9m-game-app-yono/",
  "https://netavipapp.com/pp2-game-apk/",
  "https://netavipapp.com/x89-game/"
];

async function fetchMeta(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        const titleMatch = data.match(/<title>([^<]*)<\/title>/i);
        const ogImageMatch = data.match(/<meta property="og:image"\s*content="([^"]*)"/i) || data.match(/<meta property="og:image"\s*content='([^']*)'/i);
        resolve({
          url,
          title: titleMatch ? titleMatch[1] : 'Unknown Title',
          image: ogImageMatch ? ogImageMatch[1] : 'Unknown Image'
        });
      });
    }).on('error', reject);
  });
}

async function run() {
  for (const url of urls) {
    const res = await fetchMeta(url);
    console.log(`URL: ${res.url}`);
    console.log(`Title: ${res.title}`);
    console.log(`Image: ${res.image}`);
    console.log('---');
  }
}
run();
