import React from 'react';
import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';
import { AppItem } from '../types';

interface AppCardProps {
  key?: React.Key;
  app: AppItem;
  index: number;
}

export function AppCard({ app, index }: AppCardProps) {
  return (
    <Link 
      to={`/app/${app.id}`}
      className="block bg-white rounded-lg p-2 text-center shadow-[0_2px_4px_rgba(0,0,0,0.05)] hover:shadow-md transition-shadow relative border border-gray-100"
    >
      <div className="relative w-full aspect-square mb-2 overflow-hidden rounded-lg bg-gray-50">
        {app.isNew && (
          <div className="absolute top-0 left-0 w-10 h-10 overflow-hidden z-10">
            <div className="absolute top-0 left-0 bg-[#d11013] text-yellow-300 text-[8px] font-bold py-0.5 px-4 transform -rotate-45 -translate-x-[15px] translate-y-[5px] w-[60px] text-center shadow-sm">
              NEW
            </div>
          </div>
        )}
        <img 
          src={app.icon} 
          alt={`${app.name} icon`} 
          className="w-full h-full object-cover"
        />
      </div>
      
      <h3 className="font-sans font-medium text-[11px] sm:text-[13px] text-gray-800 truncate px-1 mt-1">
        {app.name}
      </h3>
      
      <p className="text-[9px] sm:text-[11px] text-gray-400 mt-0.5">
        {app.version === 'Letest' ? 'Letest' : app.version}
      </p>
      
      <div className="flex items-center justify-center gap-[1px] mt-1 pb-1">
        {[...Array(5)].map((_, i) => (
          <Star 
            key={i} 
            className={`w-2.5 h-2.5 sm:w-3 sm:h-3 ${i < app.rating ? 'fill-yellow-400 text-yellow-400' : 'fill-gray-200 text-gray-200'}`} 
          />
        ))}
      </div>
    </Link>
  );
}
