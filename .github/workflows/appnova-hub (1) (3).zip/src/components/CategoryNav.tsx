import { CATEGORIES } from '../data';
import { cn } from '../lib/utils';

interface CategoryNavProps {
  activeCategory: string;
  onSelect: (category: string) => void;
}

export function CategoryNav({ activeCategory, onSelect }: CategoryNavProps) {
  return (
    <div className="py-6 overflow-x-auto no-scrollbar">
      <div className="flex space-x-3 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {CATEGORIES.map((category) => (
          <button
            key={category}
            onClick={() => onSelect(category)}
            className={cn(
              "px-5 py-2.5 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-200 border shadow-sm",
              activeCategory === category
                ? "bg-sky-500 text-white border-sky-400 shadow-sky-500/20"
                : "bg-slate-900/50 text-slate-300 border-white/10 hover:bg-white/10 hover:text-white hover:border-white/20"
            )}
          >
            {category}
          </button>
        ))}
      </div>
    </div>
  );
}
