import { Link } from 'react-router-dom';

export function Footer() {
  return (
    <footer className="bg-[#1e232e] text-gray-400 py-8 border-t border-[#2d3748] mt-auto">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <h3 className="font-bold text-lg text-white mb-3">Neta VIP</h3>
        <p className="text-sm mb-5 max-w-xl mx-auto">
          Descarga las mejores aplicaciones. All trademarks belong to their respective owners.
        </p>
        <div className="flex justify-center space-x-6 text-sm mb-5">
          <Link to="/" className="hover:text-white transition-colors">Home</Link>
          <Link to="/" className="hover:text-white transition-colors">Privacy Policy</Link>
          <Link to="/" className="hover:text-white transition-colors">Contact</Link>
        </div>
        <p className="text-xs text-gray-500">
          &copy; {new Date().getFullYear()} Neta VIP. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
