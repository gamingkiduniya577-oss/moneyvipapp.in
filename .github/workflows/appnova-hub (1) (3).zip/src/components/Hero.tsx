import { Search, Facebook, Twitter, Instagram, Youtube, Send } from 'lucide-react';

export function Hero({ onSearch }: { onSearch: (query: string) => void }) {
  return (
    <div className="relative pt-16 pb-12 lg:pt-20 lg:pb-16 overflow-hidden">
      {/* Background Image & Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1627856013091-fed6e4e30025?auto=format&fit=crop&q=80&w=2000" 
          alt="Gaming Background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-[#1e232e]/70 backdrop-blur-[1px]"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center mt-6 md:mt-10">
        <h1 className="text-3xl md:text-5xl font-sans font-normal text-white tracking-wide">
          Neta VIP
        </h1>
        
        <p className="mt-4 text-sm md:text-base text-gray-300 max-w-2xl mx-auto">
          We place a great deal of trust in the Neta VIP and all Yono Gaming online.
        </p>

        <div className="mt-6 max-w-2xl mx-auto flex items-center shadow-lg px-2 sm:px-0">
          <input
            type="text"
            onChange={(e) => onSearch(e.target.value)}
            className="block w-full px-4 py-3 bg-white text-gray-900 placeholder-gray-400 focus:outline-none rounded-none text-sm md:text-base"
            placeholder="App search"
          />
          <button className="px-5 md:px-8 py-3 bg-[#1b86c8] hover:bg-[#1670a6] text-white transition-colors rounded-none flex items-center justify-center">
            <Search className="w-5 h-5" />
          </button>
        </div>

        {/* Social Icons */}
        <div className="mt-6 flex justify-center gap-1.5 md:gap-2">
          {[
            { icon: <Facebook className="w-4 h-4" /> }, 
            { icon: <Twitter className="w-4 h-4" /> }, 
            { icon: <Instagram className="w-4 h-4" /> }, 
            { icon: <div className="font-bold text-sm leading-none">P</div> }, 
            { icon: <Youtube className="w-4 h-4" /> }, 
            { icon: <Send className="w-4 h-4" /> }
          ].map((social, idx) => (
             <button key={idx} className="w-8 h-8 flex items-center justify-center text-white bg-[#1b86c8] hover:bg-[#1670a6] transition-colors rounded-sm shadow-sm">
               {social.icon}
             </button>
          ))}
        </div>
      </div>
    </div>
  );
}
