import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { MOCK_APPS } from '../data';
import { Download, Send, AlertTriangle, Facebook, Twitter, MessageCircle, Menu, X, Share2, Smartphone } from 'lucide-react';
import { AppCard } from '../components/AppCard';

export function AppDetail() {
  const { id } = useParams<{ id: string }>();
  const app = MOCK_APPS.find(a => a.id === id);

  if (!app) return <div className="min-h-screen pt-24 text-center text-gray-900">App Not Found</div>;

  return (
    <div className="min-h-screen pt-[56px] pb-12 bg-[#f4f5f7]">
      <Helmet>
        <title>{app.name} App Download Get - Bonus Free</title>
        <meta name="description" content={`Download ${app.name} latest version.`} />
      </Helmet>

      <div className="max-w-[1200px] mx-auto px-4 py-8 flex flex-col lg:flex-row gap-8">
        
        {/* Main Content (Left) */}
        <div className="flex-1 w-full lg:w-[calc(100%-320px)]">
          
          {/* App Header Info */}
          <div className="flex flex-col md:flex-row mb-8 gap-6">
            {/* Left side: Icon & Buttons */}
            <div className="w-full md:w-[200px] flex flex-col items-center shrink-0">
              <img src={app.icon} alt={app.name} className="w-full max-w-[200px] h-auto rounded-[24px] mb-4 shadow-sm" />
              <a href={app.downloadLink} className="w-full bg-[#12d275] hover:bg-[#0eb866] text-white py-2 mb-2 font-bold text-[14px] flex items-center justify-center gap-2 transition-colors rounded-sm uppercase">
                <Download className="w-4 h-4" /> DOWNLOAD
              </a>
              <button className="w-full bg-[#1b86c8] hover:bg-[#1670a6] text-white py-2 font-bold text-[14px] flex items-center justify-center gap-2 transition-colors rounded-sm uppercase">
                <Send className="w-4 h-4" /> TELEGRAM
              </button>
              <div className="mt-4 text-center">
                <div className="flex justify-center items-center text-yellow-500 text-[16px] mb-1">
                  ★★★★★ <span className="text-[#1b86c8] font-bold ml-1 text-[14px]">{app.rating}</span><span className="text-gray-500 text-[12px]">/5</span>
                </div>
                <div className="text-[#333] text-[13px] font-medium">Votes: 62,847</div>
                <button className="text-gray-500 hover:text-gray-700 text-[13px] mt-2 flex items-center justify-center gap-1 w-full transition-colors"><X className="w-3 h-3"/> Report</button>
              </div>
            </div>

            {/* Right side: Title & Meta */}
            <div className="flex-1">
              <div className="text-gray-400 text-[13px] mb-2 font-medium">
                <Link to="/" className="hover:text-[#1b86c8] transition-colors">Home</Link> / <span className="text-gray-400">{app.name}</span>
              </div>
              <h1 className="text-[32px] leading-[1.2] font-bold text-[#333] mb-2">{app.name} Game Online 🎡 Play & Bet Now 💰 Bonus ₹500 Free.</h1>
              <div className="text-gray-500 text-[18px] mb-4">1.8.2</div>
              
              <div className="mb-4">
                <span className="bg-[#1b86c8] text-white text-[12px] px-3 py-1 rounded-sm font-medium">{app.name}</span>
              </div>
              
              <p className="text-[14px] text-gray-600 mb-6 font-medium">
                {app.name} Game Online 🎡 Play & Bet Now 💰 Bonus ₹500 Free.
              </p>
              
              <div className="grid grid-cols-2 gap-y-4 gap-x-4 text-[13px] mb-6">
                <div>
                  <div className="font-bold text-[#333]">Updated</div>
                  <div className="text-[#666]">Today</div>
                </div>
                <div>
                  <div className="font-bold text-[#333]">Size</div>
                  <div className="text-[#666]">66MB</div>
                </div>
                <div>
                  <div className="font-bold text-[#333]">Version</div>
                  <div className="text-[#666]">1.8.2</div>
                </div>
                <div>
                  <div className="font-bold text-[#333]">Requirements</div>
                  <div className="text-[#666]">{app.name} Game</div>
                </div>
                <div>
                  <div className="font-bold text-[#333]">Downloads</div>
                  <div className="text-[#666]">853457k+</div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <button className="bg-[#3b5998] text-white px-4 py-1.5 text-[12px] flex items-center gap-1.5 rounded-sm"><Facebook className="w-3 h-3"/> Facebook</button>
                <button className="bg-[#1da1f2] text-white px-4 py-1.5 text-[12px] flex items-center gap-1.5 rounded-sm"><Twitter className="w-3 h-3"/> Twitter</button>
                <button className="bg-[#bd081c] text-white px-4 py-1.5 text-[12px] flex items-center gap-1.5 rounded-sm">Pinterest</button>
                <button className="bg-[#1b86c8] text-white px-4 py-1.5 text-[12px] flex items-center gap-1.5 rounded-sm"><Send className="w-3 h-3"/> Telegram</button>
                <button className="bg-[#25d366] text-white px-4 py-1.5 text-[12px] flex items-center gap-1.5 rounded-sm"><MessageCircle className="w-3 h-3"/> Whatsapp</button>
              </div>
            </div>
          </div>

          {/* Description Section */}
          <div className="bg-white rounded-sm shadow-sm mb-8">
            <div className="px-6 py-4 font-bold text-[#b5b5b5] uppercase text-[15px] tracking-wider border-b border-gray-100">DESCRIPTION</div>
            <div className="p-6">
              
              <div className="border border-gray-200 rounded-sm mb-8 bg-[#fdfdfd] shadow-sm inline-block min-w-full w-full md:w-auto p-4">
                <h3 className="font-medium text-[#333] text-[16px] mb-3">Table of Contents</h3>
                <div className="flex justify-between items-start mb-4">
                  <a href={app.downloadLink} className="bg-[#419bd7] hover:bg-[#3480b5] text-white px-5 py-2 rounded-[30px] text-[15px] transition-colors inline-flex items-center gap-1.5 shadow-sm">
                    <Send className="w-4 h-4" /> Join Now
                  </a>
                  <button className="text-gray-500 border border-gray-300 rounded-sm px-1.5 py-1 bg-white hover:bg-gray-50"><Menu className="w-4 h-4" /></button>
                </div>
                
                <ul className="space-y-1.5 text-[14px] text-[#444] mt-2">
                  <li>1. <a href="#what-is-app" className="hover:text-[#419bd7]">{app.name} क्या है? पूरी जानकारी आसान हिंदी में</a></li>
                  <li>2. <a href="#how-it-works" className="hover:text-[#419bd7]">{app.name} कैसे काम करता है?</a></li>
                  <li>3. <a href="#how-to-download" className="hover:text-[#419bd7]">How to Download {app.name} Games APK.</a></li>
                  <li>4. <a href="#how-to-earn" className="hover:text-[#419bd7]">{app.name} से पैसे कैसे कमाए जाते हैं?</a></li>
                  <li>5. <a href="#is-it-safe" className="hover:text-[#419bd7]">क्या {app.name} सुरक्षित है?</a></li>
                  <li>6. <a href="#who-is-it-for" className="hover:text-[#419bd7]">{app.name} किसके लिए सही है?</a></li>
                  <li>7. <a href="#final-words" className="hover:text-[#419bd7]">{app.name} पर अंतिम राय</a></li>
                </ul>
              </div>

              <h2 id="what-is-app" className="text-[24px] font-bold text-[#111] mb-5"><span className="text-[#419bd7]">{app.name}</span> क्या है? पूरी जानकारी आसान हिंदी में</h2>
              <p className="mb-6 text-[#444] text-[15px] leading-relaxed">आज के डिजिटल दौर में मोबाइल गेमिंग सिर्फ टाइमपास तक सीमित नहीं रही है, बल्कि कई लोग इसे एक एक्स्ट्रा इनकम के मौके के रूप में भी देख रहे हैं। ऐसे में {app.name} एक तेजी से उभरता हुआ ऑनलाइन गेमिंग प्लेटफॉर्म है, जहां यूज़र रम्मी जैसे कार्ड गेम खेलकर एंटरटेनमेंट के साथ रिवॉर्ड भी हासिल कर सकते हैं।</p>
              
              <div className="flex justify-center mb-8">
                <img src={app.icon} alt={`${app.name} Game Screenshot`} className="w-full max-w-full h-auto rounded-[24px] shadow-[0_8px_30px_rgb(0,0,0,0.12)] border-2 border-gray-100" />
              </div>
              <p className="mb-8 text-[#444] text-[15px] leading-relaxed">यह प्लेटफॉर्म खासतौर पर उन लोगों के बीच लोकप्रिय हो रहा है, जो स्किल-बेस्ड गेम्स खेलना पसंद करते हैं और साथ में कुछ कमाई की संभावना भी तलाशते हैं।</p>

              <h2 id="how-it-works" className="text-[24px] font-bold text-[#111] mb-5">{app.name} कैसे काम करता है?</h2>
              <p className="mb-5 text-[#444] text-[15px] leading-relaxed">{app.name} का इंटरफेस काफी सिंपल और यूज़र-फ्रेंडली है, जिससे कोई भी नया यूज़र आसानी से शुरुआत कर सकता है।</p>
              
              <p className="mb-4 text-[#444] text-[15px] leading-relaxed">• यह इस तरह काम करता है:</p>
              
              <ul className="pl-0 mb-8 text-[#444] text-[15px] space-y-4 list-none">
                <li>• सबसे पहले ऐप या वेबसाइट पर रजिस्ट्रेशन करें</li>
                <li>• अपनी पसंद का रम्मी टेबल या गेम चुनें</li>
                <li>• गेम खेलें और अपनी स्किल से बेहतर स्कोर बनाएं</li>
                <li>• प्रदर्शन के आधार पर रिवॉर्ड या बोनस पाएं</li>
              </ul>

              <h2 id="how-to-download" className="text-[22px] font-bold text-[#333] mb-6">How to Download {app.name} Games APK.</h2>
              <p className="mb-4 text-[#444] text-[15px] leading-relaxed">Follow these simple steps to download and install the Yono game:</p>
              
              <div className="flex flex-col items-center justify-center mb-8 bg-gray-50 py-6 rounded-lg border border-gray-100">
                <a href={app.downloadLink} className="inline-block bg-[#05df05] hover:bg-[#04cc04] text-[#333] border-[2px] border-[#333] rounded-[30px] px-8 py-3 text-[16px] font-bold transition-transform hover:scale-105 shadow-md">
                  {app.name} Download
                </a>
              </div>

              <h3 className="text-[18px] font-bold text-[#333] mb-3">{app.name} की मुख्य खासियतें:</h3>
              <ul className="space-y-4 mb-8 text-[#444] text-[15px]">
                <li className="bg-white border border-gray-100 p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow"><strong className="text-[#1b86c8] block mb-1">1. आसान और क्लीन इंटरफेस:</strong> ऐप का डिज़ाइन बहुत सिंपल है, जिससे हर कोई इसे आसानी से इस्तेमाल कर सकता है।</li>
                <li className="bg-white border border-gray-100 p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow"><strong className="text-[#1b86c8] block mb-1">2. स्किल-बेस्ड गेमप्ले:</strong> यह एक स्किल गेम है, इसलिए यहां जीत आपकी रणनीति पर निर्भर करती है।</li>
                <li className="bg-white border border-gray-100 p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow"><strong className="text-[#1b86c8] block mb-1">3. तेज़ रजिस्ट्रेशन:</strong> आप आसानी से अकाउंट बना सकते हैं।</li>
              </ul>
              
              <h2 id="how-to-earn" className="text-[24px] font-bold text-[#111] mb-4">{app.name} से पैसे कैसे कमाए जाते हैं?</h2>
              <p className="mb-3 text-[#444] text-[15px] leading-relaxed">इस गेम में कमाई पूरी तरह से आपकी स्किल्स और अनुभव पर डिपेंड करती है:</p>
              
              <div className="flex justify-center mb-8 mt-6">
                <img src="{app.icon}" alt="Game Interface Slots" className="w-full max-w-full h-auto rounded-[20px] shadow-[0_8px_30px_rgb(0,0,0,0.12)] border-2 border-gray-100 " />
              </div>

              <ul className="list-disc pl-6 mb-4 text-[#444] text-[15px] space-y-2">
                <li>अच्छा खेलने पर आपको ज्यादा रिवॉर्ड्स मिलते हैं।</li>
                <li>रम्मी एक स्किल-बेस्ड गेम है, इसलिए अच्छे अनुभव का फायदा सीधा आपके स्कोर पर दिखता है।</li>
                <li>आपको गेम में समय-समय पर बोनस और स्पेशल ऑफर्स भी मिलते रहते हैं।</li>
              </ul>
              
              <div className="bg-yellow-50 border-l-4 border-yellow-400 text-yellow-800 px-5 py-4 rounded-r-md mb-8 text-[14px] flex items-start shadow-sm">
                <span className="mr-3 text-lg">⚠️</span>
                <div>
                  <strong className="block mb-1">ध्यान रखें:</strong> यह कोई फिक्स इनकम प्लेटफॉर्म नहीं है, बल्कि एक गेमिंग-रिवॉर्ड सिस्टम है।
                </div>
              </div>

              <h2 id="is-it-safe" className="text-[24px] font-bold text-[#111] mb-4">क्या {app.name} सुरक्षित है?</h2>
              <p className="mb-3 text-[#444] text-[15px] leading-relaxed">ऑनलाइन गेमिंग प्लेटफॉर्म का इस्तेमाल करते समय हमेशा सावधानी बरतना जरूरी है:</p>
              
              <ul className="list-disc pl-6 mb-8 text-[#444] text-[15px] space-y-2">
                <li>हमेशा ऑफिशियल वेबसाइट या भरोसेमंद लिंक से ही ऐप डाउनलोड करें।</li>
                <li>अपनी पर्सनल और बैंकिंग डिटेल्स किसी अनजान के साथ शेयर न करें।</li>
                <li>गेमिंग खेलते समय अपने समय और पैसे का सही संतुलन बनाए रखें।</li>
              </ul>

              <h2 id="who-is-it-for" className="text-[24px] font-bold text-[#111] mb-4">{app.name} किसके लिए सही है?</h2>
              <ul className="list-disc pl-6 mb-8 text-[#444] text-[15px] space-y-2">
                <li>उन लोगों के लिए जिन्हें रम्मी और अन्य कार्ड गेम्स खेलना पसंद है।</li>
                <li>जो अपनी स्किल्स का इस्तेमाल करके गेम खेलना चाहते हैं।</li>
                <li>जो अपने फ्री टाइम में एंटरटेनमेंट के साथ कुछ रिवॉर्ड्स पाना चाहते हैं।</li>
              </ul>

              <h2 id="final-words" className="text-[24px] font-bold text-[#111] mb-4 text-center">{app.name} पर अंतिम राय</h2>
              <p className="text-[#444] text-[15px] leading-relaxed mb-6"><span className="font-semibold">{app.name}</span> एक बहुत ही आसान और इंटरैक्टिव गेमिंग प्लेटफॉर्म है। यह यूज़र्स को रम्मी गेम के जरिए एंटरटेनमेंट और शानदार रिवॉर्ड्स जीतने का मौका देता है। अगर आपको कार्ड गेम्स खेलना पसंद है और आप खाली समय का मज़ा बढ़ाना चाहते हैं, तो आप इसे एक बार जरूर आज़मा सकते हैं।</p>
              
              <div className="flex flex-col items-center justify-center mb-4 mt-8 py-8 border-t border-gray-100">
                <a href={app.downloadLink} className="inline-flex bg-[#12d275] hover:bg-[#0eb866] text-white rounded-[30px] px-10 py-3.5 text-[16px] font-bold transition-transform hover:scale-105 shadow-md uppercase items-center gap-2">
                  <Download className="w-5 h-5" /> {app.name} Download
                </a>
              </div>
            </div>
          </div>

          {/* Related Apps */}
          <div className="bg-white rounded-sm shadow-sm mb-8">
            <div className="px-6 py-4 font-bold text-gray-400 uppercase text-[14px] tracking-wider border-b border-gray-100">RELATED APPS</div>
            <div className="p-6 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
              {MOCK_APPS.slice(0, 4).map((related, idx) => (
                <AppCard key={related.id} app={related} index={idx} />
              ))}
            </div>
          </div>

          {/* Tags */}
          <div className="bg-white rounded-sm shadow-sm">
            <div className="px-6 py-4 font-bold text-gray-400 uppercase text-[14px] tracking-wider border-b border-gray-100">TAGS</div>
            <div className="p-6 flex flex-wrap gap-2">
              {[
                `Download ${app.name} Game`, app.name, `${app.name} Apk`, `${app.name} App`,
                `${app.name} Bonus 80`, `${app.name} Download`, `${app.name} Game`,
                `${app.name} Game Apk`, `${app.name} Game App`, `${app.name} Game Download`,
                `${app.name} Game Download Apk`, `TOP ${app.name} Game Download App`,
                `${app.name} Game Download game`, `${app.name} Game Download game download`,
                `${app.name} Game Login`, `${app.name} Game LUNCH`, `${app.name} Game.com`,
                `${app.name}.com`
              ].map(tag => (
                <span key={tag} className="bg-[#1b86c8] text-white text-[13px] px-3 py-1.5 rounded-sm font-medium">{tag}</span>
              ))}
            </div>
          </div>

        </div>

        {/* Sidebar (Right) */}
        <div className="w-full lg:w-[320px] space-y-8 shrink-0">
          
          {/* Search */}
          <div className="flex shadow-sm">
            <input type="text" className="flex-1 px-4 py-3 border border-gray-200 border-r-0 focus:outline-none text-[14px] bg-white" placeholder="" />
            <button className="bg-[#1b86c8] text-white px-6 py-3 text-[14px] font-medium hover:bg-[#1670a6] transition-colors border border-[#1b86c8]">Search</button>
          </div>
          
          {/* Recent Posts */}
          <div className="bg-white rounded-sm shadow-sm overflow-hidden">
            <div className="bg-[#f9f9f9] px-5 py-4 font-bold text-gray-600 uppercase text-[14px] border-b border-gray-100">RECENT POSTS</div>
            <div className="p-0">
              {MOCK_APPS.slice(0, 5).map((relatedApp) => (
                <div key={relatedApp.id} className="group border-b border-gray-100 last:border-0 p-4 hover:bg-gray-50 transition-colors cursor-pointer flex gap-4 items-center">
                  <div className="shrink-0">
                    <img src={relatedApp.icon} alt={relatedApp.name} className="w-[60px] h-[60px] rounded-lg object-cover shadow-sm group-hover:scale-105 transition-transform" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-[14px] font-bold text-[#444] group-hover:text-[#1b86c8] leading-snug mb-1 line-clamp-2">{relatedApp.description}</h4>
                    <div className="flex items-center gap-3 mt-1.5">
                      <div className="flex items-center text-yellow-400 text-[12px]">
                        ★★★★★
                      </div>
                      <span className="text-[11px] text-white bg-[#1b86c8] px-1.5 py-0.5 rounded-sm">{relatedApp.version}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Comments */}
          <div className="bg-white rounded-sm shadow-sm overflow-hidden">
            <div className="bg-[#f9f9f9] px-5 py-4 font-bold text-gray-600 uppercase text-[14px] border-b border-gray-100">RECENT COMMENTS</div>
            <div className="p-5 text-[14px] text-gray-500">
              No comments to show.
            </div>
          </div>

          {/* Archives */}
          <div className="bg-white rounded-sm shadow-sm overflow-hidden">
            <div className="bg-[#f9f9f9] px-5 py-4 font-bold text-gray-600 uppercase text-[14px] border-b border-gray-100">ARCHIVES</div>
            <ul className="text-[14px] text-[#444]">
              <li className="hover:text-[#1b86c8] hover:bg-gray-50 transition-colors cursor-pointer border-b border-gray-100 px-5 py-3">June 2026</li>
              <li className="hover:text-[#1b86c8] hover:bg-gray-50 transition-colors cursor-pointer border-b border-gray-100 px-5 py-3">May 2026</li>
              <li className="hover:text-[#1b86c8] hover:bg-gray-50 transition-colors cursor-pointer px-5 py-3">April 2026</li>
            </ul>
          </div>

          {/* Categories */}
          <div className="bg-white rounded-sm shadow-sm overflow-hidden">
            <div className="bg-[#f9f9f9] px-5 py-4 font-bold text-gray-600 uppercase text-[14px] border-b border-gray-100">CATEGORIES</div>
            <ul className="text-[14px] text-[#444] h-[600px] overflow-y-auto custom-scrollbar">
              {[
                '01 slots apk', '01 slots app', '01 slots game', '101Z GAME', '101Z GAME Apk', 
                '101Z GAME App', '101Z GAME DOWNLOAD', '1X GAME', '1X GAME APK', '1X GAME App',
                '1X GAME DOWNLOAD', '21 Game', '21 Game Apk', '21 Game App', '21 Game Download',
                '360 Inr game', '567 slots apk', '567 slots app', '567 slots game', '777 Bet Game',
                '777 Bet Game Apk', '777 Bet Game App', '777 Bet Game Download', '777 VIP',
                '777 VIP APK', '777 VIP App', '777 VIP GAME', '777 VIP GAME DOWNLOAD'
              ].map(cat => (
                <li key={cat} className="hover:text-[#1b86c8] hover:bg-gray-50 transition-colors cursor-pointer flex items-start px-5 py-3 border-b border-gray-50">
                  <span className="text-gray-300 mr-3 text-[10px] mt-[3px]">⯈</span> {cat}
                </li>
              ))}
            </ul>
          </div>

        </div>

      </div>
    </div>
  );
}


