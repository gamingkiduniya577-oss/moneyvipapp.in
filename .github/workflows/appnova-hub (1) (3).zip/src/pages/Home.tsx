import { useState, useMemo, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { Hero } from '../components/Hero';
import { AppCard } from '../components/AppCard';
import { MOCK_APPS } from '../data';

const ITEMS_PER_PAGE = 30;

export function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);

  const filteredApps = useMemo(() => {
    return MOCK_APPS.filter((app) => 
      app.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  const totalPages = Math.ceil(filteredApps.length / ITEMS_PER_PAGE);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery]);

  const currentApps = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredApps.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredApps, currentPage]);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#f0f2f5] pb-12">
      <Helmet>
        <title>Neta VIP - Apps más calificadas</title>
        <meta name="description" content="Descarga las mejores aplicaciones de juegos y casino." />
      </Helmet>
      <Hero onSearch={setSearchQuery} />
      
      <main className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 mt-4">
        <div className="bg-[#f0f2f5] pt-2 pb-3">
          <h2 className="text-[15px] sm:text-lg font-sans text-gray-700 px-1">Latest Apps</h2>
        </div>
        
        {currentApps.length > 0 ? (
          <>
            <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 gap-1.5 sm:gap-3">
              {currentApps.map((app, idx) => (
                <AppCard key={app.id} app={app} index={idx} />
              ))}
            </div>

            {totalPages > 1 && (
              <div className="mt-8 flex justify-start items-center space-x-2 px-1">
                {Array.from({ length: totalPages }).map((_, i) => {
                  const page = i + 1;
                  return (
                    <button
                      key={page}
                      onClick={() => handlePageChange(page)}
                      className={`px-4 py-3 min-w-[3rem] text-sm sm:text-base font-medium transition-colors ${
                        currentPage === page
                          ? 'bg-[#2b71b8] text-white'
                          : 'bg-white text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      {page}
                    </button>
                  );
                })}
                {currentPage < totalPages && (
                  <button
                    onClick={() => handlePageChange(currentPage + 1)}
                    className="px-4 py-3 text-sm sm:text-base bg-white text-gray-700 hover:bg-gray-100 transition-colors"
                  >
                    Next &raquo;
                  </button>
                )}
              </div>
            )}
          </>
        ) : (
          <div className="mt-12 text-center text-gray-500">
            No apps found matching "{searchQuery}"
          </div>
        )}
      </main>
    </div>
  );
}
