export interface AppItem {
  id: string;
  name: string;
  icon: string;
  version: string;
  rating: number;
  category: string;
  description: string;
  downloadLink: string;
  screenshots: string[];
  features: string[];
  isNew?: boolean;
}
